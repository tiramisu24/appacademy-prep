# Week 3: Object-Oriented Projects

## Monday: Options Hashes and Method Missing

#### Readings
- [Symbols and Options Hashes][symbols-options-hashes]
- [Method Missing][method-missing]

[symbols-options-hashes]: ./w3d1/readings/symbols-options-hashes.md
[method-missing]: ./w3d1/readings/method-missing.md

## Tuesday: Mastermind

#### Readings
- None

## Wednesday: Battleship

#### Readings
- None

## Thursday: Hangman

#### Readings
- None

## Friday: Review

#### Exercises
- Refactor your old work and work on bonus problems.

## Bonus
- [Maze Solver][maze-solver]

[maze-solver]: ./bonus/maze-solver.md
