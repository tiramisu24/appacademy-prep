class HumanPlayer
  def get_play
    puts "Enter coordinates seperated by coma (x, y)"
    gets.chomp
  end
end
